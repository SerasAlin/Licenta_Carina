AdminBro.UserComponents = {}
import Component1 from '../adminPanelComponents/Dashboard'
AdminBro.UserComponents.Component1 = Component1