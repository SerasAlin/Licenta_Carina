import React from 'react'
import { Box } from 'admin-bro'

const Dashboard = (props) => {
    return (
        <Box>
            <h1>
                Welcome to Admin page !
            </h1>
        </Box>
    )
};

export default Dashboard