0) Din folderul "node-api" rulezi comanda "npm install" in terminal ---> instalezi librariile pentru server
0.1) Din folderul "material-kir-react-master" adica root-ul proiectului, rulezi comanda "npm install" --->  instalezi librariile pentru front
(pasii de mai sus este de ajuns sa ii executi o singura data)


Rulare:

1) Din folderul "node-api" rulezi comanda "node index.js" in terminal ---> pornesti serverul
2) Din folderul "material-kir-react-master" adica root-ul proiectului, rulezi comanda "npm start" ---> pornesti clientul (front-ul)